package com.example.a3004java001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Second_page_skip_input extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page_skip_input);
    }


    public void launchActivists(View x){
/*
        Intent i = new Intent(this,Home_page.class);

        String Name = ((TextView)findViewById(R.id.Name)).getText().toString();
        i.putExtra("Name",Name);

        String Age = ((TextView)findViewById(R.id.age)).getText().toString();
        i.putExtra("Name",Age);



        startActivity(i);*/

    }










}