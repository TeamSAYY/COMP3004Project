package com.example.a3004java001;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Meditate_info_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditate_info_page);
    }
}